//
//  NYTimeViewModel.swift
//  NYTimes
//
//  Created by Siddharth Kadian on 22/10/18.
//  Copyright © 2018 Siddharth Kadian. All rights reserved.
//

import Foundation

struct NYTimeViewModel {
    
    var title:String
    var date:String
    var byline:String
    var section:String
    var abstract:String
    var url:String
    var thumbnailImageStr:String
    var largeImageStr:String

    init(data:MostViewedResults) {
        self.byline = data.byline ?? ""
        self.date = data.publishedDate ?? ""
        self.title = data.title ?? ""
        self.section = data.section ?? ""
        self.abstract = data.abstract ?? ""
        self.url = data.url ?? ""
        
        let media = data.media as [Media]
        let mediaData = media[0].mediaMetadata as [MediaMetadata]
        if  mediaData.count > 0 ,  let url = mediaData[0].url {
            self.thumbnailImageStr = url
        }else{
            self.thumbnailImageStr = ""
        }
        if  mediaData.count > 7 ,  let url = mediaData[8].url {
            self.largeImageStr = url
        }else{
            self.largeImageStr = ""
        }
    }
    
}

func filterBySearchKeywords(searchKeyword: String, resultsArray : Array<MostViewedResults>) -> Array<MostViewedResults> {
    
    if searchKeyword.count == 0 {
        return resultsArray
    }
    
    let filteredArray = resultsArray.filter({
        (result : MostViewedResults) -> Bool in
        return (result.title?.localizedCaseInsensitiveContains(searchKeyword))!
    })
    
    return filteredArray
}

