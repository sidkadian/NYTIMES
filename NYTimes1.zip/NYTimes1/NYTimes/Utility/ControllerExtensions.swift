//
//  ControllerExtensions.swift
//  NYTimes
//
//  Created by Siddharth Kadian on 22/10/18.
//  Copyright © 2018 Siddharth Kadian. All rights reserved.
//

import UIKit

//MARK: -  Application theme color
extension UIColor {
    static var appThemeColor: UIColor {
        return UIColor.init(red: 63.0/255.0, green: 225.0/255.0, blue: 180.0/255.0, alpha: 1.0)
    }
}

extension UIStatusBarStyle {
    var preferredStatusBarStyle : UIStatusBarStyle {
        return .lightContent
    }
}

//MARK: -  UISearchBar Appearance
extension UISearchBar {
    
    func customSearchBar(){
        UISearchBar.appearance().tintColor = UIColor.white
        UISearchBar.appearance().barTintColor = UIColor.appThemeColor
    }
}

//MARK: -  UINavigationBar Appearance
extension UINavigationBar {

    func customAppNavigationBar(){
        // Set navigation bar tint / background colour
        UINavigationBar.appearance().barTintColor = UIColor.appThemeColor
        
        // Set Navigation bar Title colour
        UINavigationBar.appearance().titleTextAttributes = [NSAttributedString.Key.foregroundColor:UIColor.white]
        
        // Set navigation bar ItemButton tint colour
        UIBarButtonItem.appearance().tintColor = UIColor.white
        
        //Set navigation bar Back button tint colour
        UINavigationBar.appearance().tintColor = UIColor.white
        
        //Transcluency off to align the background colors of navigation bar and bar button items
        UINavigationBar.appearance().isTranslucent = false
    }
}

//MARK: -  UIViewController Alerts
extension UIViewController {
    
     func showAlert(title:String,message:String, delegate:UIViewController,cancelButtonTitle:String) -> Void {
        var delegate = delegate
        if #available(iOS 8.0, *) {
            let alert = UIAlertController(title:title, message:message, preferredStyle: UIAlertController.Style.alert)
            alert.addAction(UIAlertAction(title:cancelButtonTitle, style: UIAlertAction.Style.default, handler: nil))
            let rootViewController = UIApplication.shared.keyWindow?.rootViewController;
            delegate = rootViewController!;
            delegate.present(alert, animated: true, completion: nil);
        } else {
            // Fallback on earlier versions
            let alert = UIAlertView(title:title,message:message,delegate:delegate,cancelButtonTitle:cancelButtonTitle);
            alert.show();
        }
        
    }
    
}

extension UIImageView{

    func loadImage(urlString:String){
        self.image = UIImage(named: "PlaceHolderImage_Table")
        guard let url = URL(string: urlString) else {
            return
        }
        
        if (appCache.object(forKey: urlString as AnyObject) != nil) {
            self.image = appCache.object(forKey: urlString as AnyObject) as? UIImage
        }else{
            let session = URLSession.shared.dataTask(with: url) { (data, response, error) in
                if let data = data , let image = UIImage(data: data) {
                    DispatchQueue.main.async {
                        self.image = image
                        appCache.setObject(image, forKey: urlString as AnyObject)
                    }
                }
            }
            session.resume()
        }
    }
}

extension UIStoryboard {
    
    var mainStory:UIStoryboard {
        let mainStoryBoard = UIStoryboard(name: "Main", bundle: nil)
        return mainStoryBoard
    }
    
    var details:DetailViewController {
        return  mainStory.instantiateViewController(withIdentifier: "DetailViewController") as! DetailViewController
    }
    
    var master:MasterViewController {
        return  mainStory.instantiateViewController(withIdentifier: "MasterViewController") as! MasterViewController
    }
    
    var detailsNav:UINavigationController {
        return  mainStory.instantiateViewController(withIdentifier: "DetailsNav") as! UINavigationController
        
    }
}
