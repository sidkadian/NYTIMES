//
//  Constants.swift
//  NYTimes
//
//  Created by Siddharth Kadian on 22/10/18.
//  Copyright © 2018 Siddharth Kadian. All rights reserved.
//

import Foundation
import UIKit

enum URLType: String {
    case Day = "1"
    case Week = "7"
    case Month = "30"
    
    func getDisplayName() -> String {
        switch self {
        case .Day:
            return "Day"
        case .Week:
            return "Week"
        case .Month:
            return "Month"
        }
    }
    
    func url()->String{
        return Constants.ServiceURL.urlRequest(for: self)
    }
    
}

extension URLType: CaseIterable {}

struct Constants {
        
    enum AlertString: String {
            case somethingWrong = "Something went wrong please try again later"
            case specificPeriod = "See items for specific period"
    }
    
    struct ServiceURL {
        fileprivate static let baseURLString = "http://api.nytimes.com/svc/mostpopular/v2/mostviewed/all-sections/"
//        fileprivate static let keyString = ".json?api-key=4820a19587ef4514a6e6a39d90bf1ef9&offset=0"
        fileprivate static let keyString = ".json?api-key=K81oOyCveDxRRGqSiEAmoTRIgCmHllIj&offset=0"

        static func urlRequest(for type: URLType) -> String {
            
            let urlString: String
            switch type {
            case .Day:
                urlString = ServiceURL.baseURLString + "1" + ServiceURL.keyString
            case .Week:
                urlString = ServiceURL.baseURLString + "7"  + ServiceURL.keyString
            case .Month:
                urlString = ServiceURL.baseURLString + "30"  + ServiceURL.keyString
            }
            return urlString
        }
    }
}
