//
//  DetailSummaryTableViewCell.swift
//  NYTimes
//
//  Created by Siddharth Kadian on 22/10/18.
//  Copyright © 2018 Siddharth Kadian. All rights reserved.
//

import UIKit

class DetailSummaryTableViewCell: UITableViewCell {

    @IBOutlet weak var categoryLabel: UILabel!
    @IBOutlet weak var dateLabel: UILabel!
    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var descriptionLabel: UILabel!
    @IBOutlet weak var newsImageView: UIImageView!
    
//    var dataViewModel:NYTimeViewModel? {
//        didSet {
//            dataRepresentationInView()
//        }
//    }
    var dataViewModel:NYTimeViewModel?
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
    func dataRepresentationInView(){
        guard let dataViewModel = dataViewModel else {
            return
        }
        self.titleLabel.text = dataViewModel.title
        self.dateLabel.text = "🗓 " + dataViewModel.date
        self.descriptionLabel.text = dataViewModel.abstract
        self.categoryLabel.text = dataViewModel.section
        self.newsImageView.loadImage(urlString: dataViewModel.largeImageStr)
    }


}
