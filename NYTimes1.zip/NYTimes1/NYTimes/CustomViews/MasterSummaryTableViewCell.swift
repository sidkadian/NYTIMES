//
//  MasterSummaryTableViewCell.swift
//  NYTimes
//
//  Created by Siddharth Kadian on 22/10/18.
//  Copyright © 2018 Siddharth Kadian. All rights reserved.
//

import UIKit

class MasterSummaryTableViewCell: UITableViewCell {

    @IBOutlet weak var thumbnailView: UIImageView!
    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var byLineLabel: UILabel!
    @IBOutlet weak var publishDateLabel: UILabel!
    
    var dataViewModel:NYTimeViewModel? {
        didSet {
            dataRepresentationInView()
        }
    }

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
    func dataRepresentationInView(){
        guard let dataViewModel = dataViewModel else {
            return
        }
        self.titleLabel.text = dataViewModel.title
        self.publishDateLabel.text = "🗓 " + dataViewModel.date
        self.byLineLabel.text = dataViewModel.byline
        self.thumbnailView.loadImage(urlString: dataViewModel.thumbnailImageStr)
    }

}
