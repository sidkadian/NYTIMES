//
//  NYTimeModel.swift
//  NYTimes
//
//  Created by Siddharth Kadian on 22/10/18.
//  Copyright © 2018 Siddharth Kadian. All rights reserved.
//

import Foundation


struct NYTimeModel: Decodable {
    var status:String?
    var copyright:String?
    var numResults:Int?
    var results:[MostViewedResults]
}

struct MostViewedResults: Decodable {
    var url:String?
    var adxKeywords:String?
    var column:String?
    var section:String?
    var byline:String?
    var type:String??
    var title:String?
    var abstract:String?
    var publishedDate:String?
    var source:String?
    var id:Int?
    var assetId:Int?
    var views:Int?
//    var desFacet:[String]?
//    var orgFacet:[String]?
//    var perFacet:[String]?
//    var geoFacet:[String]?

    var media:[Media]
}

struct Media: Decodable {
    var type:String?
    var subtype:String?
    var caption:String?
    var copyright:String?
    var approvedForSyndication:Int?
    var mediaMetadata:[MediaMetadata]
    
    private enum CodingKeys: String, CodingKey {
        case mediaMetadata = "media-metadata"
        case type, subtype, caption, copyright, approvedForSyndication
    }

}

struct MediaMetadata: Decodable {
    public var url:String?
    public var format:String?
    public var height:Int?
    public var width:Int?
}
