//
//  Services.swift
//  NYTimes
//
//  Created by Siddharth Kadian on 22/10/18.
//  Copyright © 2018 Siddharth Kadian. All rights reserved.
//

import Foundation

class Services: NSObject {
    static let shared = Services()
    func fetchData(url:String,completion: @escaping (NYTimeModel?, Error?) -> ()) {
    
                let urlString = url
                guard let url = URL(string: urlString) else { return }
                URLSession.shared.dataTask(with: url) { (data, _, err) in
                    DispatchQueue.main.async {
                        if let err = err {
                            print("Failed to get data from url:", err)
                            return
                        }
        
                        guard let data = data else { return }
        
                        do {
                            let decoder = JSONDecoder()
                            decoder.keyDecodingStrategy = .convertFromSnakeCase
                            let timesData = try decoder.decode(NYTimeModel.self, from: data)
                            DispatchQueue.main.async {
                                completion(timesData, nil)
                            }
                        } catch let jsonErr {
                            print("Failed to decode:", jsonErr)
                        }
                        
                    }
                    }.resume()
        
    }
    
}
